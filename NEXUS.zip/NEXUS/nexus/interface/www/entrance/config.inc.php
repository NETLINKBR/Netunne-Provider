<?

	$senha = md5("visual");
	define("LOGIN","admin");
	define("PASSWORD",$senha);
	define("IDLETIME",54000);
	
?>