INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'CRISTIANO SOBRINHO', 'cvsobrinho@gmail.com', null,'', '', '', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Carla', 'cacaconcentino@hotmail.com', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Carla', 'cacaconcentino@hotmail.com', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'SHEILA VILELA CORREIA', 'sheila.vilela@hotmail.com', null,'', '', '', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Eliane Martins', 'eliane1martins@terra.com.br', null,'', '', '', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Fernando Paulino de Oliveira', 'fernando@ileel.ufu.br', null,'', '', '', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Alinne de Brito Siqueira', 'alinnesiqueira@yahoo.com.br', null,'', '', '', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Dejanir Junior', 'juneko@bol.com.br', '1986-12-29','Rua ismael gomes da sailva, 131', '38405-380', 'Faculdade Catolica de Uberlandia', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'lucimar aparecida dias', 'lucimar24@yahoo.com.br', '1969-06-24','praca renato humbert calcagno,100 ap 24 bl 09 tibery', '38405-054', 'universidade federal de uberlandia', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Elis Lopes', 'elis@dpipublicidade.com.br', '1974-01-06','rua Domingues de S�, 403/204, Icara�, Niter�i', '24220-090', '', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'D�bora Cristina de Oliveira Nunes', 'deborinh_a@yahoo.com.br', '1987-12-23','', '', 'Universidade federal de Uberl�ndia', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Adalberto Wodianer Marcondes', 'dal@envolverde.com.br', '1956-06-02','Rua simpatia, 179', '05436-020', 'Ag�ncia Envolverde', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Revista Acad�mica', 'revistaacademica@yahoo.com.br', null,'', '', 'Revista Acad�mica', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'raphael frauches victer', 'rfvicter@yahoo.com.br', null,'', '', 'Est�cio de S�', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Raphael Frauches Victer', 'rfvicter@yahoo.com.br', null,'', '', 'Est�cio de S�', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Paola Frauches Victer', 'pvicter@hotmail.com', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Lucas Vettorello', 'lucas.ve@bol.com.br', '1984-08-19','Rua Moises Candido Veloso, 211', '95900-000', '', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'JULIA VILLELA BATISTA', 'julia_batista@yahoo.cm', null,'', '', '', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Andr�ia Ernesto', 'aernesto2000@yahoo.com.br', null,'Rua das Orquideas, 16 apto 402', '', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Thiago Scot', 'thiagoscot@gmail.com', null,'', '', 'PUC', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'yanne sant anna malcher', 'nany_nany1@ig.com.br', '1986-01-13','rua cinco de julho 350/903', '22051-030', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'maria cecilia', 'cicaearp@gmail.com', '1986-01-15','', '', 'PUC', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Frederico de Barros Falc�o de Lacerda', 'frelacerda@gmail.com', '1986-08-20','R. Paulo C�sar de Andrade - n� 200/302 - Laranjeiras', '22221-090', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Joanna Oliveira', 'joannamayra@hotmail.com', '1985-05-20','Rua Timoteo da Costa, 600/104 Bloco 1', '22450-130', 'PUC-RJ', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Camilla Silva Pires', 'millinhapires@gmail.com', '1987-04-03','Rua Anchieta - n� 29/1104 - Leme', '22010-070', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Luciana Marins', 'lumarins@gmail.com', '1985-07-01','Rua Sidney M�ller, 71 apt. 102 - Ilha do Governador', '21941-060', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'carla cruz guimar�es de almeida', 'carla.suzi@gmail.com', null,'R. auta de souza, 106, Santa Maria, Belo Horizonte', '30525-060', '', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Jamile Coimbra Thom� Tavares Ferreira', 'jamilecttf@gmail.com', null,'Av. Belisario Leite 200/202', '22621-270', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'jessicaca rodrigues costa', 'jessicamozin@yahoo.com.br', '1987-02-03','', '', 'Pontificia universidade catolica de minas gerais', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'patricia Hasselmann Camardella Schiavo', 'patyschiavo@hotmail.com', '1986-05-07','rua. Leopoldo Miguez 15/501 copacabana', '22060-020', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Ricardo de Castro Azevedo', 'ricardodecastro@globo.com', '1985-10-05','Av. Sernabetiba 3600 bloco 6 apt 304', '22630010', 'PUC-RIO', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Mariana Tobar', 'mmtobar@gmail.com', null,'Rua Conde de Bonfim, 1325/501-A', '20530-001', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'princiane cabral da silva', 'princiane_paper@hotmail.com', '1988-02-18','estrada do rio pequeno, lote 19, Taquara- Jacarepagu�', '22723-195', '', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Luciana Affonso Brito', 'lbrito@empresajunior.com.br', '1985-12-26','', '', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Carla Knoplech Madureira', 'cacaukm@yahoo.com.br', '1986-01-02','Real Grandeza 275/104', '22281-31', 'PUC-RJ', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'jovemempreendedor', 'jovemempreendedor@gmail.com', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Newton de Lima Bezerr', '', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Newton de Lima Bezerra Neto', 'newtonlbneto@gmail.com', '1983-10-20','', '', 'UNESA - EST�CIO DE S�', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Marcelo Freitas Santino', 'marcelosantino@gmail.com', '1985-10-17','Rua S�o Francisco Xavier n� 152 apt. 301', '20550-012', 'Univercidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Newton de Lima Bezerra Neto', 'newtonlbneto@gmail.com', '1983-10-20','Av. Gerem�rio Dantas 287 , apt 108', '22735-000', 'UNESA - Universidade Est�cio de S�', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Eric Nunes Kern', 'ericnkern@yahoo.com.br', '1985-02-05','Rua Professor Jos� Pe�anha - 24', '24325-310', 'Pontif�cia Universidade Cat�lica do Rio de Janeiro (PUC-Rio)', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Michele Garcia', 'michelegarcia001@bol.com.br', '1981-08-05','Tenente Coronel Brito, 678, apto. 302', '96810-020', 'UNISC- Universidade de Santa Cruz do Sul/RS', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Milena Borges e Vasconcellos', 'borges.milena@gmail.com', '1983-10-24','Rua Dr Mario Rego dos Santos 322/301 Vila Laura', '40270-200', 'Universidade Federal da Bahia', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'PEDRO HENRIQUE MONNERAT FERREIRA', 'MONNERAT_PEDRO@YAHOO.COM.BR', '1986-06-10','R. MARQUES DE SAO VICENTE, 154/302', '22451-040', 'PUC-RIO', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Graziela Figueiredo de Carvalho', 'grazielacarvalho18@yahoo.com.br', '1985-08-11','Rua Humait�, 170, Humait�', '22261-001', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Melina Marques Cardoso', 'marcilene_dasilva@hotmail.com', '1981-04-08','Rua Humait� ,170', '22261-001', 'Puc-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Priscila M. Delfini', 'pridelfini@Hotmail.com', null,'', '', 'Faculdade Italo Brasileira', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Fl�via Rodrigues Nunes', 'flaviarnunes@yahoo.com.br', null,'Rua Santo Amaro 229/101', '31035-320', 'Puc-Minas', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'maria carmen caprara costamilan', 'mariacc@unisc.br', '1964-03-03','av. independ�ncia n� 2293', '96815-900', 'unisc', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Fl�via Rodrigues Nunes', 'flaviarnunes@yahoo.com.br', null,'Rua Santo Amaro 229/101', '31035-320', 'Puc-Minas', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Natasha Szczerb', 'natashasz@hotmail.com', null,'Rua Redentor 27/101 - Ipanema', '22421-030', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Felipe Infante de Castro', 'felipeinfante@yahoo.com', '1985-10-20','Av. Sernambetiba, 3600, bl6 apto1503', '22630-010', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Giuliano Pflugrath Carraro', 'gpcarraro@gmail.com', '1984-09-26','Av. Bernardo Vieira de Melo, 1800 apt703', '54410-010', 'UFPE', 'PE' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Adriano', 'aoshifw@yahoo.com.br', '1985-11-12','br-116 km 109 20707 casa 25', '81690-400', 'UFPR', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Gregory', 'g.iyama@hotmail.com', '1985-02-16','Tijuca', '20521-055', 'Univercidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Gregory', 'g.iyama@hotmail.com', '1985-02-16','Tijuca', '20521-055', 'Univercidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Marcelo de morais silva', 'marmoraesilva@hotmail.com', '1979-01-29','r.alm barroso 31 r.vermelho,salvador', '41950-350', 'ufba', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Gregory', 'g.iyama@hotmail.com', '1985-02-16','Tijuca', '20521-055', 'Univercidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Marcelo de morais silva', 'marmoraesilva@hotmail.com', '1979-01-29','r.alm barroso 31 r.vermelho,salvador', '41950-350', 'ufba', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'jiuber salvador santana', 'jiubersalvador@yahoo.com.br', 'l964-09-26','Av. Guia Lopes 327 Nossa Senhora das Gra�as', '38402-006', 'Faculdade Cat�lica de Uberl�ndia', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Jo�o Carlos Cochlar de Oliveira', 'jccochlar@globo.com', null,'Rua Tim�teo da Costa, 600/104', '22450-130', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Paula Chiapeta Fadigas', 'pchiapeta@yahoo.com.br', null,'Av. das Am�ricas, 1245/111', '22631-000', '', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Robson de almeida santos', 'robsoncivil@oi.com.br', '1981-10-22','', '', 'ufba', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Arthur Pinho', 'arthurpinho@yahoo.com.br', null,'av. canal de marapendi, 1600, apt. 2002', '22631-050', 'PUC RIO', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Juliana Fortuna de Almeida', 'julianafortuna@uol.com.br', '1984-09-21','Rua Pio Correia 72 apt 604', '22461-240', 'Puc-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Natalia Serpa Anastacio', 'natserpa@hotmail.com', '1985-03-26','Rua Humaita 77/701', '22261-000', 'Pontif�cia Universidade Cat�lica', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Carolina Madalon P Braga', 'carol_madalon@hotmail.com', null,'rua pio correa 80 apt 405', '22461-240', 'ibmec', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Let�cia Soares Minette', 'leticiaminette@yahoo.com.br', null,'', '', 'UFMG', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Giulianna de Azevedo Ramos', 'giuazevedo@yahoo.com.br', '1984-01-06','Rua das Laranjeiras, 466/408 Laranjeiras', '22240-006', 'UNIVERSIDADE CANDIDO MENDES', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Rhanes Bitencourt Camurugy', 'rhanes@gmail.com', '1983-12-31','rua dos ossos', '40301-340', 'UFBA - Universidade Federal da Bahia', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Alessandra Colla�o da Silva', 'ally_ufsc@yahoo.com.br', '1985-06-28','Av. Max Schramm, 2428 ap.2 Bl.2', '88095-000', 'Universidade Federal de Santa Catarina', 'SC' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Lucas Rafael de Farias Santana', 'lucasengcivil@oi.com.br', null,'Av Joana Angelica, 588, Nazare', '40050-000', 'UFBA', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Dalton Valim Alcoba Ruiz', 'dalton@etur.com.br', '1952-05-28','', '', 'UCB', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Luciana Mendes Caetano', 'luciana@caetano.com.br', '1971-12-08','Rua Humberto de Campos, 67 apto 158 B', '04311-080', 'Atualmente estou em busca de uma P�s em Marketing', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bianca Arrieta', 'bia.arrieta@oi.com.br', null,'', '', 'UERJ', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Thiago De Paula', 'thiago_ufpr@ufpr.br', null,'', '', 'UFPR', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Emanuel Damaceno da Silva', 'i9comunicacao@brturbo.com.br', '1985-11-12','rua Clarice Cerqueira, 168', '85501-140', 'FADEP ( Faculdade de Pato Branco)', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Eduardo Ferraz Martins', 'eduardoferrazuff@yahoo.com.br', null,'Rua Uruguai 380 bl d 507', '20510-060', 'UFF', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Eduardo Ferraz Martins', 'eduardoferrazuff@yahoo.com.br', null,'Rua Uruguai 380 bl d 507', '20510-060', 'UFF', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Eduardo Ferraz Martins', 'eduardoferrazuff@yahoo.com.br', null,'Rua Uruguai 380 bl d 507', '20510-060', 'UFF', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'DOUGLAS CORTES', 'cortes.douglas@gmail.com', '1985-11-23','', '21760-180', 'PUC-rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'luis felipe chagas de souza', 'felipedibob@hotmail.com', null,'rua', '23052-130', 'moacyr sreder bastos', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Thiago Fernandes Scalice', 'thiago@jobcompublicidade.com.br', null,'', '', 'Escola Senai Theobaldo de Nigris', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Rhanes Bitencourt Canurugy', 'rhanesb@gmail.com', '1983-12-31','Rua dos Ossos n29, Bairro', '40301-340', 'Ufba - Universidade Federal da Bahia', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'jaciara figueiredo', 'mdif@ibest.com.br', '1959-11-23','av d joao vi 74 edf tupixuara', '40285-000', 'faculdade sao salvador', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Patr�cia Massote Barbarisi', 'paty.mb@terra.com.br', '1986-05-10','Rua Paulo Barreto, n.46, apto.1208', '22280-010', 'Pontif�cia Universidade Cat�lica- PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Patr�cia Massote Barbarisi', 'paty.mb@terra.com.br', '1986-05-10','Rua Paulo Barreto, n.46, apto.1208', '22280-010', 'Pontif�cia Universidade Cat�lica- PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Fernanda Caroline Gon�alves Vilhena', 'nan_dinha_mg@hotmail.com', '1986-09-26','Rua Esmeralda 405 apto 302 Prado', '30410-080', 'UFMG', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'BIBIANA', 'bibiana@propale.com.br', '1983-05-06','', '', 'u', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'rosiane da rosa', 'rosianerosa1712@yahoo.com.br', null,'r. marino jorge dos santos, 739', '88136-200', 'UFSC', 'SC' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Ant�nio Jorge de Oliveira Feij�', 'antonio.feijo@gmail.com', '1964-04-16','Rua Samambaia 148 casa 8', '24754-350', '', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Iuri Kothe', 'iuri.pv@comunitas.org.br', null,'', '', 'Portal do Voluntario', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Elis TESTE', 'elis@dpipublicidade.com.br', null,'Rua Tavares de macedo, 95, sl 705, Icara� - Niter�i', '24220-215', 'DPI', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Karin N. Filus', 'karin.filus@hotmail.com', '1985-07-16','', '', 'Pucpr', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'POLLYANNA DE SOUZA SANCHES', 'pollyannassanches@hotmail.com', '1982-05-08','Rua Janu�ria 480/apt 202 . Bairro Floresta', '31110-060', 'Faculdade Est�cio de S� de Belo Horizonte', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Jairo Pinto Bispo', 'jairo@ufba.br', '1985-08-24','Travessa Fe em Deus', '41213-270', 'UFBA', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'bruno schiavo', 'brunohcschiavo@hotmail.com', '1988-03-18','r. leopoldo miguez 15/501 copacabana', '22060-020', 'PUC-RIO', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bernardo Gomes Pereira Castelh�es', 'bernardo_cast@yahoo.com.br', '1984-10-21','r. Bar�o de Jaguaripe 313 apt 202', '22421-000', 'puc-rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Patricia Dodsworth', 'patricia.penna@hotmail.com', '1986-06-23','R. Bar�o de Icara� 21 apt 406 flamengo', '22250-100', 'puc', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'patrick vigio', 'patrick_vigio@yahoo.com', '1986-07-18','r. Dr Luis Capriglione 127 (casa) Itanhag�', '22641-050', 'puc', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Elaine Marlise K. Monteiro', 'marlise_kauer@yahoo.com.br', null,'1� RCGd Rua G casa 701 - SMU', '70631-035', 'UniCEUB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'vivian camargo', 'vivian@klicknet.com.br', '1977-08-29','av.Brig Faria Lima, 1826 cj 403', '01452-001', '', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'RICARDO ALVES NOGUEIRA', 'ra_nog@yahoo.com.br', null,'r capitao jose de souza 65', '13020-470', 'unicamp', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Ricardo Lopes Passos', 'rick_nm@hotmail.com', '1985-07-09','R. Carlos Klemtz 1410', '81320-000', 'UNIFAE', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Jos� Antonio Gon�alves Motta', 'no.ideas.for.an.original.login@gmail.com', null,'Rua Prudente de Morais, 1408/301 - Ipanema - Rio de Janeiro/RJ', '22420-042', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'BADRA ALVES VILARINHO', 'BADRAVILARINHO@HOTMAIL.COM', '1981-08-22','', '', 'UNICEUB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Gabriela da Silva Dias Guedes', 'belinhagabi000@hotmail.com', '1987-06-12','rua. Bernardo Rodrigues Fernandes, 17', '07194-540', 'UNIVERSIDADE DE GUARULHOS', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Nicholas Franzen Matte', 'nicholasmatte@ea.ufrgs.br', null,'', '', 'UFRGS', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Jansen', 'jansenluiz@sestsenat.com.br', '1982-10-14','', '', 'Centro Universit�rio de Bras�lia - UniCEUB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Camila Ganzella', 'cganzella@hotmail.com', null,'Rua Claudio, 213 - apt� 54 - Vila Romana', '05043-000', 'Faculdade C�sper L�bero', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Leonardo Grimaldi Ruggiero', 'felycia@terra.com.br', null,'Rua Manuel de Avila,31', '03072-030', 'FGV', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Andr� Luiz Machado', 'beronhahccuritiba@gmail.com', null,'alameda cabral 328', '80410-210', 'Puc-pr', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Ana Carolina', 'ana.cost@bol.com.br', null,'Rua Honorio Maia, 592', '03072-000', 'USP - Odonto', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bruno Cardoso Portela', 'bcportela@yahoo.com.br', '1981-08-10','R. Montevideu, n� 354, Ara��s, Vila Velha', '29103-025', 'Universidade Federal do Esp�rito Santo', 'ES' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bruno de Souza Gaspar', 'pastor78@gmail.com', '1978-10-28','', '40045-150', 'UFBA', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Marcelle Costa de Oliveira', 'celle_oliveira@msn.com', null,'R. General Pereira da Silva, 146 / ap. 902', '24220-031', 'Universidade Est�cio de S�', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Suzeli de Castro Almeida', 'suzelialmeida@yahoo.com.br', '1984-08-24','Rua S�o Geraldo n� 249 Centro Arcos', '35888-000', 'Escola Superior em Meio Ambiente', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Cristiane Nazar garcia', 'crisn_garcia@yahoo.com.br', '1984-02-04','', '', 'PUCRS', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Maria Clara W. Batalha', 'mariaclarawb@hotmail.com', '1986-11-04','avenida epitacio pessoa 2530', '22471-003', 'PUC-RIO', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Let�cia Bueno Hida', 'lelehida@terra.com.br', '1987-04-02','Agnaldo Manuel dos Santos,314', '04116-250', 'FAAP', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Simone Becker', 'simonebecker2001@yahoo.com.br', null,'', '', 'UNISC', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'ashanti beal', 'ashanti_floripa@hotmail.com', '1985-02-04','', '', 'universidade federal de santa catarina', 'SC' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'ashanti beal', 'ashanti_floripa@hotmail.com', '1985-02-04','', '', 'universidade federal de santa catarina', 'SC' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Julia Tages da Silva', 'juliatsd@yahoo.com.br', null,'Jo�o Manoel 2800 apt', '97510-240', 'PUCRS-CAMPUS 2', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'JAIRO J. SiLVA', 'jairo.jsilva@yahoo.com.br', null,'Ruia dos Aimores, 116', '13081-030', 'Pontificia Universidade Catolica de Campinas', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'JAIRO J. SiLVA', 'jairo.jsilva@yahoo.com.br', null,'Ruia dos Aimores, 116', '13081-030', 'Pontificia Universidade Catolica de Campinas', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'JAIRO J. SiLVA', 'jairo.jsilva@yahoo.com.br', null,'Ruia dos Aimores, 116', '13081-030', 'Pontificia Universidade Catolica de Campinas', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Josiane Carmo Rodrigues', 'jojorodrigues@oi.com.br', null,'R. Mal. Mascarenhas de morais, 258/01', '22030-040', 'PUC -Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'', '', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Erica Rodrigues', 'erica.silva@pop.com.br', '1983-03-10','Rua Real Grandeza 51 casa 120 Bairro Botafogo / Nova Iguacu', '', 'Instituto Superior de Ensino Celso Lisboa', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Jos� Henrique Lannes Monteiro', 'jose.lannes@ig.com.br', null,'Rua S�o Francisco Xavier, 466/308,Tijuca, Rio de Janeiro', '20550-013', 'Centro Universit�rio Celso Lisboa', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Alexandre Santo', 'xandre.rj@globo.com', '1983-07-02','', '', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Leandro Trindade da Silva', 'trindadeleo@hotmail.com', '1985-09-24','', '', '', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Cintya Figueiredo Fontana', 'cintya_fontana@yahoo.com.br', '1984-07-25','Rua Capit�o Domingos Castellano, 567', '82300-020', 'PUC PR', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Cintya Figueiredo Fontana', 'cintya_fontana@yahoo.com.br', '1984-07-25','Rua Capit�o Domingos Castellano, 567', '82300-020', 'PUC PR', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Andr� Luiz Bertoldi Oberziner', 'andreoberziner@hotmail.com', '1984-10-08','Rua Jornalista Tito Carvalho num. 155 Res It�lia', '88040-480', 'UFSC', 'SC' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Alcides Lenhari J�nior', 'lenhari@yahoo.com', '1980-08-27','Rua Olyntho de Barros, 52', '', 'Puccamp', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Thamirys Layla Voz', 'thamirys.layla@gmail.com', '1987-11-29','Rua gard�nio Scorzato, 559', '82100-240', 'UTP - Universidade Tuiuti do Paran�', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Marcia Regina da Silva', 'marciarers@yahoo.com.br', null,'', '', 'UNISC', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'alexandro fabio machado', 'foribundoo@hotmail.com', null,'estrada das acacias', '06385-023', 'puc', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'alexandro fabio machado', 'foribundoo@hotmail.com', null,'estrada das acacias', '06385-023', 'pontificia universidade catolica(Puc)', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Joanna Figueiredo Paraizo Garcia', 'joannaparaizo@gmail.com', null,'Rua Conde Bernadote 26 bloco 1A, apto 1401 Leblon', '22430-200', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Alexandro Teles de Oliveira', 'atotelles@hotmail.com', '1981-05-30','Rua Velha do Pero Vaz, Av. Maria, 19 - Pero Vaz', '40335-600', 'UFBA', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Eloisa de Sousa Cantu�ria', 'cantuaria@ucb.br', '1967-09-03','HIGS 703 BL C CASA 23', '70331-703', 'Universidade Cat�lica', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Juliana Alves Ponticelli', 'juliponticelli@yahoo.com.br', '1980-02-03','Avenida Ulbra, 168', '92420-000', 'Universidade Federal do Rio Grande do Sul - UFRGS', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Gustavo de Oliveira de Antoni', 'gustavo.antoni@gmail.com', null,'', '', 'UFRGS', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Pedro Henrique Benite', 'pbenite@gmail.com', '1983-11-30','', '', 'UniCEUB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'NADJA BACHESCHI BENETTI', 'NADJAPSI@HOTMAIL.COM', '1974-10-20','SQN 109 ASA NORTE', '70752-113', 'UNB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Iara Cristina Teixeira', 'iarinhabio@yahoo.com.br', '1986-01-24','R- Lucas Luis de Faria 1003 Sto Antonio -Arcos', '35588-000', 'ESCOLA SUPERIOR E MEIO AMBIENTE / FEVASF', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Ma�ra Garcia Santos', 'ma_publicidade@yahoo.com.br', '1985-07-09','', '', 'UniCEUB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'', '', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'HELDER BASTOS DAS NEVES', 'hbneves@gmail.com', null,'Rua Bar�o 207 bloco', '21321-620', 'Universidade Est�cio de S�', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'VIRGINIA BATISTA PINHEIRO', 'etevalldo@bol.com.br', '1981-01-21','Quadra 4 Casa 47', '', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Hewerson Gomes', 'hewerson.gomes@souzacruz.com.br', '1973-12-15','Rua S�o Jo�o, 8', '38401-694', 'Souza Cruz S.A.', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Hewerson Gomes', 'hewerson.gomes@souzacruz.com.br', '1973-12-15','Rua S�o Jo�o, 8', '38401-694', 'UNITRI - Centro Universitario do Triangulo', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Toni Miss�l', 'tonimissel@ibest.com.br', '1982-04-24','Rua Jeronimo Coelho, 30/23', '90010-240', 'PUC', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Leo Lopes de Oliveira Neto', 'leolopesneto@yahoo.com.br', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Eduardo Galinskas Filho', 'eduardo.galinskas@souzacruz.com.br', '2006-10-25','Rua Bol�via n�400, Apto 301', '89050-300', 'Funda��o Universidade Regional de Blumenau', 'SC' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Marcelo Trevisol', 'marcelo_filos@hotmail.com', null,'Luiz Le�o 01 Centro', '80030-010', 'PUC PR', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Marcelo Trevisol', 'marcelo_filos@hotmail.com', null,'Luiz Le�o 01 Centro', '80030-010', 'PUC PR', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Nilo Santos Miranda', 'santyosremoeta@hotmail.com', '1986-03-21','Rua Cear�, 1192 Ed Vila dos Corinthos', '41830-451', 'UFBA', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'felipe cohen', 'felipecohenj@yahoo.com.br', '1985-08-09','R. Eurico Cruz, 33', '22461-200', 'Puc-rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'felipe cohen', 'felipecohenj@yahoo.com.br', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Clovis Santana Larangeira', 'clovis.santana@pop.com.br', null,'QE 28 CONJUNTO L CASA 16 GUAR� 2', '71060-122', 'cENTRO UNIVERSIT�RIO DE BRAS�LIA - UNICEUB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Aline Elisa M�ller', 'alineelisamuller@hotmail.com', '1985-12-11','Rua Ven�ncio Aires, 633', '96810-100', 'unisc', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Douglas Muniz', 'douglaskz@yahoo.com.br', '1976-04-19','Rua sobradinho,965', '96840-500', 'UNISC - Universidade de Santa Cruz', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Thiago Chaves da Silva', 'thiagochaves2004@hotmail.com', '1986-02-25','', '', 'Universidade de Bras�lia- UnB', 'GO' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Ant�nio Edjerson de Sousa Alves', 'edjerson@sobra.org', null,'Rua Pedro Aguiar Carneiro, 78', '62020-690', 'Universidade Estadual Vale do Acara�', 'CE' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Jadson Nascimento Santos', 'jadinbahia@yahoo.com.br', '1981-09-25','Rua FAusto n� 810 casa 03', '26580-220', 'Universidade Est�cio de S�', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Jadson Nascimento Santos', 'jadinbahia@yahoo.com.br', '1981-09-25','Rua FAusto n� 810 casa 03', '26580-220', 'Universidade Est�cio de S�', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Fernanda', 'fezimmer@yahoo.com.br', '1981-01-10','', '', 'Unisc', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'M�rcia Elisa Ribeiro do Vale', 'meribvale@yahoo.com.br', '1983-02-13','r. Po�os de Caldas, 81 casa 2 Santa In�s', '31080-080', 'Universidade Federal de Minas Gerais', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Carina', 'carinamartins@mx2.unisc.br', '1988-08-05','Santa cruz do sul', '96800-000', 'Unisc', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Andr� Lobato Bou�res', 'andreboueres@gmail.com', '1986-01-08','QI 23 lote 12 Ap 209 Guara II', '71060-638', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Rosiana Kist', 'rosianakist@yahoo.com.br', '1987-09-19','Pinhal Trombudo', '96878-000', 'Unisc', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Leandro Soares Amazonas', 'amazonas_filho@hotmail.com', '1983-12-21','rua ministro garlos coqueijo costa', '41640-070', 'fib', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Carla M. Viegas', 'carlinha_bass@pop.com.br', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'manuela oliveira santos', 'meinusssa@hotmail.com', '1983-03-27','rua jardim federa��o, n� 451 apt� 201', '40231-060', 'ufba', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Allan Lemos da Silva', 'allanlemos82@yahoo.com.br', '1982-08-10','sqs 203 bld ap203', '70233-040', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Michele Maria de Souza Maciel', 'michellythebest@yahoo.com.br', '1983-12-12','Rua Graja� n� 72 bloco 03 apt 05', '25565-080', 'UNISUAM', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'FABIANA MARIA SOARES', 'BIAMSOARES@HOTMAIL.COM', null,'RUA SAULO DE TARSO GOULART N�129', '31510-130', 'PONTIFICIA UNIVERSIDADE CATOLICA DE MINAS GERAIS', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Antonio Augusto de Miranda e Souza', 'friburgo2005@gmail.com', '1968-07-14','clsw 302 bloco c sl 157-Bras�lia', '70673-613', 'Universidade de Brasilia-UNB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Leonardo da Silva Motta', 'lsmotta@gmail.com', '1985-11-16','QS 05 Rua 123 Casa 03', '71563-940', 'UCB - Univeridade Cat�lica de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'S�rgio Vieira', 'sergio@infohomerio.com', '1964-05-18','Rua Luis de Brito, 47', '20785-360', 'InfoHome', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Sabrina rocha', 'sabrinart@zipmail.com.br', null,'', '', 'UNISC', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'marcelo pires', 'markcelopires@hotmail.com', '1985-11-06','rua uruguai 324 casa 16', '20510-060', 'UniveCidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Talita Botelho Bruzzi', 'tbbruzzi@globo.com', null,'', '', 'Universidade Federal do Rio de Janeiro', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Marcelle Naim Nehme', 'marcelle.naim@ig.com.br', '1985-01-19','Rua Baro de Mesquita 380, bl', '20540-003', 'Pontifica Universidade Catolica do Rio de janeiro', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Fabio Jose Mahle', 'fabiomahle@yahoo.com.br', null,'', '', 'UNISC', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Betina Giehl', 'betigiehl@yahoo.com.br', null,'', '', 'UNISC', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'BRUNO LEANDRO ZANETI', 'zaneti@eco.unicamp.br', '1985-03-01','R Latino Coelho 1256', '13087-010', 'Inst. Economia UNICAMP', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Karina', 'kakosilveira@gmail.com', '1987-02-06','', '', 'UFSC', 'SC' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Polianna Alves Reges', 'polianna.ucb@gmail.com', '1984-10-21','QR 411 conj 06 casa 22', '72321-206', 'Universidade Cat�lica de Brasilia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'sheila vanderci', 'sheila_vmm@yahoo.com.br', null,'av 19 de maio', '11250-000', '', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'JO�O PAULO WAYAND DE ANDRADE', 'jpwa22@yahoo.com.br', '1979-03-07','Rua General Abreu e Lima, 211/102', '54400-410', 'UFPE', 'PE' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Fernanda Tude', 'nandapeg2@hotmail.com', '1986-11-21','Rua Humberto Porto, Bl 325A, Ap 101, Cj colinas de Pitua�u, No coamont 04', '41250-560', 'UFBA', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Talita Duvanel', 'litaduvanel@hotmail.com', '1986-09-25','', '', 'UFRJ', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Dulcin�a Nascimento Medeiros', 'duegabi@gmail.com', null,'SQN 412 Bl. J Ap. 307', '70867-100', 'IESB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Andr� Luiz Maurer', 'de.maurer@gmail.com', '1986-06-23','Rua Thomaz Flores 887 / 403', '96810-090', 'UNISC - Universidade de Santa Cruz do Sul', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'rejane silva lima', 'rejanesilvalima@hotmail.com', '1977-10-10','qr 412 conj 08 casa 18', '72320-109', 'centro universitario - UNIEURO', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'nilson gustavo de godoy', 'godoy@atima.com.br', null,'av. dr. gumercindo veludo, 1413', '14860-000', 'moura lacerda', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'nilson gustavo de godoy', 'godoy@atima.com.br', null,'av. dr. gumercindo veludo, 1413', '14860-000', 'moura lacerda', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Carolina Meneses de Souza Silva', 'imeiudacarol@gmail.com', '1983-04-24','', '', 'UniCEUB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Carolina Meneses de Souza Silva', 'imeiudacarol@gmail.com', null,'', '', 'UniCEUB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'ursula cuperman', 'ursulacuperman@yahoo.com.br', '1981-04-01','rua barata ribeiro 135/308', '22011-000', 'UniverCidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'vivian teixeira da silva', 'vivitsilva@yahoo.com.br', '1985-11-15','rua alto gar�as, 145', '23031-010', 'Centro Universit�rio da Cidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'mariana dutra da silva passos', 'marianadsp@gmail.com', '1986-10-02','', '', 'UniverCidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Ana MAria Bastos de Carvalho', 'anamar_carvalho@hotmail.com', '1977-03-21','Q NN 22 conj D casa 54', '72220-220', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Gustavo Alexandre', 'gustavooo@gmail.com', null,'rua bar�o de mesquita 663 ap 901', '20710-130', 'UFRJ', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Paulo Vin�cius Oliveira Lago', 'paulovlago@yahoo.com.br', null,'', '', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Felipe Eugenio de Oliveira Vaz Sampaio', 'felsvaz@yahoo.com.br', '1984-07-28','Quadra 8, Conjunto D, Casa 56 - Sobradinho-DF', '73005-080', 'Universidade de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Patrick Rafael Teixeira Batista', 'patrick.batista@ibest.com.br', '1983-01-25','Rua Marechal Deodoro,441 apto 1003', '80020-320', 'Universidade Tuiuti do Paran�', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Pedro Henrique Benite', 'pbenite@gmail.com', '1983-11-30','SHIS QI 27 Conjunto 17 Casa 15', '71675-170', 'Centro Universit�rio de Bras�lia - UniCEUB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'RAFAELCALDAS FERREIRA DA SILVA', 'faelcaldas@gmail.com', '1987-06-17','', '', 'PUC', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'ANA LUISA ALMENARA PELISSON LUCAS DOS SANTOS', 'lualmenara@hotmail.com', '1988-06-04','av augusto calmon 1795', '29900-060', 'UFES', 'ES' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Leopoldo Jorge Alves Neto', 'leopoldoalves@gmail.com', null,'', '70875-020', 'IESB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Silvia Elena Froes Villela Alfradique', 'silvia_alfradique@yahoo.com.br', '1981-02-03','', '', 'Universidade Est�cio de S�', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'LUCIANA ALBUQUERQUE', 'bsbluciana@hotmail.com', '1974-11-13','SHIS QI 27 Conjunto 17 Casa 14', '71675-170', 'IESB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Robson Wendel Soares Lira', 'boblira30@yahoo.com.br', '1977-12-30','', '', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'maria fernanda de almeida saback', 'nandasaback@yahoo.com.br', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Paulo Jos� Rabelo de Castro', 'pjrabelo@pop.com.br', '1986-07-12','', '', 'UCB', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Leonardo Garcia Santos', 'pjrabelo@pop.com.br', null,'', '', 'UCB', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Humberto Gomes E da Silva', 'pjrabelo@pop.com.br', null,'', '', 'UCB', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Nicolas Sartori dos Santos', 'pjrabelo@pop.com.br', null,'', '', 'UCB', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Mayara Nascimento de Farias', 'mayarafarias@pop.com.br', '1985-08-16','QELC 04 Bloco A-1 apto 203. Guar�.', '70030-000', 'Universidade Cat�lica de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Marcos Andre de Sousa Novais', 'msnovais2004@yahoo.com.br', '1984-08-23','Qnl 08 conj. F casa 04', '72155-806', 'UniCEUB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Daniela Virginia Rios Dias', 'danivirginia@gmail.com', null,'Av.Central lt', '71710-500', 'UCB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bruna de Rezende Martins', 'brunarezins@yahoo.com.br', '1982-09-26','SHCES qd 1407 - bl A - apt 304', '70658-471', 'Universidade de Brasilia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Dimitri Carvalho', 'dimisc@pop.com.br', null,'', '', 'Universidade de Bras�lia', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'alessandra dos santos ferreira', 'lekales@gmail.com', '1981-01-05','Qsf 07 casa 304 tag sul', '72025-570', 'univesidade cat�lica de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Simone Fernandes Gon�alves', 'simonef@ons.org.br', '1974-07-01','QNO 09 Conjunto A casa 33', '72252-091', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Patricia Monteiro', 'petymonteiro@yahoo.com.br', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'S�rgio de Souza e Silva', 's3sergio@hotmail.com', null,'Av. das Amoreiras, 6100 , Apto-44, bloco- B21', '13050-909', 'Anhanguea Educacional - FACIII - Campinas', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Tatyana Aranda Andrade da Silva', 'taty.aranda@uol.com.br', null,'SQN 108 Bl. C Apto. 604', '70744-030', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Michele Miranda de Azevedo', 'michele_unb@yahoo.com.br', '1982-01-04','Condom�nio San Diego lote 13 ap 111', '71680-362', 'UnB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Rafael Lima Dantas', 'luizdantas@saquarema.com.br', '1987-05-04','Rua Umnelina Almeida Sim�es, 263', '28990-000', 'FERLAGOS Fund. Educac. Regi�o dos Lagos', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Samara Maultasch de Oliveira', 'samaoliveira@gmail.com', '1984-12-01','Rua Tonelero 203/601', '22030-000', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'MARCELO MORAES DE SOUZA FERREIRA SILVA', 'marcelo.msfs@gmail.com', '1986-04-15','SQS 305 BLOCO A APTO. 202', '70352-010', 'UnB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Ana Paula Rezende Costa', 'anapaularez@yahoo.com.br', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Anildo Messias Costa', 'anapaularez@yahoo.com.br', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Deicimar Aparecida Rezende Costa', 'anapaularez@yahoo.com.br', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Rafael G. de Castro', 'rafael.castro@doisnovemeia.com.br', '1985-10-12','SQS 108 Bloco C Apto. 601', '70347-030', 'Universidade de Bras�lia - UnB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'marcilene oliveira', 'lulu56marci@yahoo.com.br', null,'ccsw 04', '70680-450', 'Universidade catolica', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'RYAN ALVES LEITE', 'ryanbsb@gmail.com', null,'CONJ. 2HI RUA 26 CASA 42', '72860-026', 'UNIEURO', 'GO' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'luiz paulo gomes', 'luizpaulogomes@hotmail.com', null,'r.jorge salvarani,260', '08720-070', 'umc', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Polianna Alves Reges', 'polianna.ucb@gmail.com', '1984-10-21','QR 411 conj 06 casa 22', '72321-206', 'Universidade Cat�lica de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Deborah Kelly Ramos de Souza', 'debiinha@hotmail.com', '1986-04-01','', '', 'Unieuro', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'SIDNEI DA SILVA JUNIOR', 'AGROCREDICV@COOXUPE.COM.BR', '1985-06-03','AV. OSCAR ORNELAS 329, A', '37880-000', 'CENTRO UNIVERSITARIO DE GUAXUPE', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'PEDRO HENRIQUE SILVA DA COSTA', '', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Pedro Henrique Silva da Costa', 'pedrohscosta@oi.com.br', null,'CNG 09 LOTE 07 AP 201- TAG', '72130-095', 'UNIEURO', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Rosmari Dutra', 'rosi@yazigi.com', null,'Manoel Ribeiro n 302', '95800-000', 'Unisc', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Ros�ngela Osterno Vieira', 'rosangelaosterno@hotmail.com', '1971-09-14','R. Interna 38', '78700', '', 'MT' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Tatiane Saraiva Santos', 'tatianesaraiva@hotmail.com', '1985-01-25','', '', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'jhonatan ricardo bender', 'jhonatanbender27@yahoo.com.br', '1980-08-27','edmundo baumhardt 48', '96550-080', 'unisc', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Manuela Pinto Gama dos Santos', 'manuelapgs@gmail.com', '1983-06-29','SQN 209 Blobo K Apto 303', '70854-110', 'Instituto de Ensino Superior de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Janina Kassya Silva Peixoto', 'nina_gatynha@hotmail.com', '1986-10-17','SQS 409 bloco I entrada A apt 101', '70258-090', 'Centro Universitario Euro Americana', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Eliane Siqueira', 'heliane_siqueira@hotmail.com', '1951-10-31','Indaiatuba', '13330-000', '', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'elis lopes', 'elis@dpipublicidade.com.br', '1974-01-06','Rua Tavares de macedo, 95, sl 705, Icara� - Niter�i', '24220-215', 'DPI', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'D�dalo Amadeo Ziech', 'dedaloamadeo@gmail.com', '1975-02-14','SQN 312 Bl G Ap 101', '70765-070', 'ALUB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Thiago Guerra Rosado Cruz', 'thiagoelt@gmail.com', '1987-04-14','Av. Carlo Meziano, 337, lt06, bl10/212', '21931-590', 'Universidade Federal Fluminense', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Ailim Oliveira Braz Silva', 'ailim_ucb@yahoo.com.br', '1987-06-10','QE 4, Conjunto G, Casa 24', '71010-073', 'Universidade Cat�lica de Bras�lia - UCB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Anna Virg�nia e Silva Souza', 'anita.sunshine@gmail.com', '1985-07-30','Quadra 313 Conj I Casa 02', '72505-243', 'Universidade Cat�lica de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Ailim Oliveira Braz Silva', 'ailim_ucb@yahoo.com.br', '1987-06-10','QE 4, Conjunto G, Casa 24', '71010-073', 'Universidade Cat�lica de Bras�lia - UCB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Veronica Bemfica Bernardes', 'veronicabemfica@gmail.com', null,'SMPW Q.04 CJ.06 LT.03 UNID E', '71735-040', 'Universidade Cat�lica de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Renan Cassius MEndes Souza', '', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Renan Cassius Mendes Souza', 'renancassius@yahoo.com.br', '1988-03-09','Cnb 14 lote 05 bloco b apt 312', '72115-145', 'Universidade Cat�lica de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Chelon Cristina V.Ver�ssimo', 'cheloncris@gmail.com', null,'', '', 'Universidade Cat�lica de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Daniel C�sar Nunes Cardoso', 'daniel_lampiao@hotmail.com', '1979-03-23','Rua S�o Jos� de Baixo, 114.apt. 301, Barbalho', '', 'Univeridade Federal da Bahia', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Andr� Lobato Bou�res', 'andreboueres@gmail.com', '1986-01-08','', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Andr� Lobato Bou�res', 'andreboueres@gmail.com', '1986-01-08','', '', 'Uniceub', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Meirelaine T. C. Q. Mendes', 'meirelain@bol.com.br', '1977-11-29','Qd 310 Conj. 1 A Casa 13', '72600-000', 'Universidade Catolica de Brasilia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Cec�lia C�ndida Fras�o Vieira', 'ceciliacandida@hotmail.com', null,'', '', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Daniele Carvalho Andrade', 'danidca@uol.com.br', '1988-02-25','SQ 12 Quadra 01 Casa 05', '72888-000', 'Centro Universit�rio - UNIEURO', 'GO' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'ludimilla', 'ludi_@walla.com', '1985-08-25','', '', 'ceub', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Emerson Pires de Souza', 'esouza@niltonlins.br', '1949-03-05','Av. Prof. Nilton LIns - Flores', '69000-000', 'Centro Universit�rio Nilton LIns', 'AM' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'ALEXANDRE DA SILVA MATOS', 'alexandresilvamatos@yahoo.com.br', '1981-11-30','rua JOSE DIAS VIEIRA 217 RIO BRANCO BHTE-MG', '31535-040', '', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Adriane de Oliveira', '', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Adriane de Oliveira Lemes', 'drilemesblue@hotmail.com', '1983-08-24','QNM 06 Conj', '72210-060', 'Universidade de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Leonardo Vidal Agostini', 'leonardogremio1903@hotmail.com', '1986-01-24','SQN 103 Bloco B apto 103 Asa Norte', '70732-020', 'UniCeub', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'paula moraes pereira', 'pmpaula@zipmail.com.br', '1967-09-26','SQN 210 Bloco H apt 409', '70620-080', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Manoel Soares Adorno', 'manoel.adorno@yahoo.com.br', '1952-12-28','QI 23/24 St. Ind. de Taguatinga', '72135-230', 'ACIT - Assoc. Com. e Industrial de Taguatinga', 'ES' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Andre Luiz Alves Ferreira', 'alafy@yahoo.com.br', '1970-08-01','QNM 03 Conj. G casa 40', '72215-037', 'Faculdades NDA', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Tatiana dos Santos Rocha', 'tatianadrocha@ig.com.br', '1984-05-17','QNP 10 CONJ Q CASA 46', '72230-100', 'UNIVERSIDADE CATOLICA DE BRASILIA', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'TATIANA DOS SANTOS ROCHA', 'tatianadrocha@ig.com.br', '1984-05-17','QNP 10 CONJ Q CASA 46', '72230-100', 'UNIVERSIDADE CATOLICA DE BRASILIA', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Alexandre de iOlivieira Souza', 'alexrbx@globo.com', '1971-06-15','QE 04 Bl. B9, Apt 303', '71110-150', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Helo�sa Alves de Sousa', 'heloisadf@msn.com', '1987-08-20','Qr 109 conjunto 02 casa 16', '72301-303', 'Universidade de Brasilia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Gilberto Manoel de Fran�a Leite', 'gilberto@facibra.com.br', '1960-03-26','QI 08 CONJ. K CASA 08 GUARA I', '71010-115', 'Faculdade de Ci�ncias de Brasilia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Danylla Ibrahim', 'danylla.moreira@facibra.com.br', '1979-11-27','', '', 'Faculdade de Ci�ncias de Bras�lia', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Aldemir Santos', 'aldemirjunior@hotmail.com', null,'', '', 'UNOPAR', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'', '', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'ROSANA LIMA DE FARIAS', 'rosana_rlf@oi.com.br', '1977-05-28','AOS 01 BL. G APT�612 AREA OCTOGONAL', '70660-017', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Patr�cia Lima Nobre Lopes', 'patlnl@ig.com.br', '1980-05-19','', '', 'Unicesp', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Luis claudio Cardoso Costa', 'luccatz@terminalzero.com.br', null,'', '', 'Unicesp', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Marcela Elena', 'cela34@hotmail.com', null,'', '', 'Unicesp', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Vin�cius Lob�o Ribeiro', 'vilobao@gmail.com', '1984-09-25','SHIS QI 16 CONJUNTO 02 CASA 18', '71640-220', 'UniCEUB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Ana Flavia Torres Costa e Silva Couto', 'anaflaviatorres@hotmail.com', '1976-11-06','SHIS QL 16 conjunto 3 casa 5', '71640-235', 'Fortium', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Antonio Portero Campoi', 'apcampoi@hotmail.com.br', '1959-06-13','SQN315 Bloco J apto 305', '70774-100', 'Caixa Seguradora S.A.', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'CLEIDES SILVA CAMPOS', 'cleides_@hotmail.com', '1974-08-15','QMSW02 CONJ. C LOTE 10 APTO. 101 SUDOESTE SOF', '70680-200', 'UNIDF', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Shayla Silvestre de Abreu', 'ssilvestredeabreu@yahoo.com.br', '1979-10-06','Qr 415 conj 07 Casa 01', '72323-007', 'UNOPAR', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Val�ria Oliveira de Souz Sousa', 'valeriaesc@gmai.com.br', '1976-03-15','CNF 01 LOTE 11 APT� 01 ED. OURO VERDE', '72125-515', 'UNIVERSIDADE CANDIDO MENDES- ATAME', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Paulo Roberto Nery Ribeiro', 'prnr@pop.com.br', '1971-02-25','SQN 313 Bl. B apt 607', '70766-020', 'Unidf', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Magn�lia Vieira de Sousa', 'magnoliavieira@gmail.com', '1954-07-30','QNL 04 BL. B APT� 125 Taguatinga-DF', '72155-040', 'SENAC', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'PAULO JOS� LOPES', 'pjlopes680@terra.com.br', '1946-06-29','ALAMEDA FLAMBOYANT 450', '88103-125', '', 'SC' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Jorge Antonio de Araujo Brito', 'jbrito26@gmail.com', '1977-10-10','QE 42 Conj S Casa 03', '71000-000', 'Universidade Catolica de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'CLEBER ANDRADE COSTA', 'clebercosta@terra.com.br', null,'Cond. Res. Santos Dumont QBR 07 Bl. D Apt 22', '72594-004', 'Comando da Aeron�utica', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'PATRICIA DOS SANTOS GUIMARAES', 'patricia.guimaraes@aduaneiras.com.br', '1974-06-03','', '', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Raimunda L. G. da Silva', 'pietrarwm@yahoo.com.br', null,'SQN 104 Bl. I ap. 103', '70733-090', 'Unidf', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Lorena Maria de Alencar Normando da Fonseca', 'fonseca.lori@gmail.com', '1987-03-13','', '', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Jamille P Knop', 'jamilleknop@hotmail.com', '1982-06-30','QI 06 Bloco P Apto 206 Guar� I', '71010-164', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Guilherme Carvalho da Silva', 'gc.silva@gmail.com', '1983-04-15','', '', 'IESB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Patr�cia Cristine', 'pcristine@bol.com.br', '1976-12-20','SHCGN 709 - F - 204', '70750-760', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'robson valadares sousa', 'robson.valadares@gmail.com', null,'setor G norte area esp. 21 casa 34 Tag. Norte', '72130-080', 'Fiplac', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'GIANE CRISTINA ALEXANDRE', 'GIANE_C_A@YAHOO.COM.BR', '1984-04-30','QUADRA 02 CONJUNTO 2 E CASA 28 JD RORIZ - PLANALTINA', '73340-205', 'UNIVERSIDADE PAULISTA', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'V�nia de Sousa Naascimento', 'vaniapedagogaueg@ibest.com.br', '1974-09-18','SQ 13 Qd 06 casa 14 Cidade Ocidental', '72880-000', 'Universidade Estadual de Goi�s', 'GO' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Weslley Marlei', 'marleyelite@hotmail.com', '1985-09-25','Colonia Agricola Aguas Claras, Chac.35, Lote 30A', '71090-000', 'Unieuro', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'MARCOS ANDRE ALVES BARBOSA', 'ALVES.BARBOSA@HOTMAIL.COM', '1965-01-22','SHIS QL 22 CONJ 05 CASA 06', '71650-255', 'IESB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'SILVANA MAGELA ALVES LUCIO', 'sillucio@ucb.br', null,'', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'ROQUE MARCOS DE OLIVEIRA', 'roquefusca@hotmail.com', null,'', '', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'JOS� ROGERIO DE JESUS ABRANTES', 'ROGERIOABRANTES3@POP.COM.BR', '1962-09-15','QNM 36 CONJUNTO O CASA 29', '72615-145', 'FACULDADE PROJE��O', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'George Luis Santiago Santos', 'georgeluisb@yahoo.com.br', '1978-10-04','Rua Henrique rabelo 1413', '60110-540', 'Faculade Evolutivo', 'CE' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Edson Ribeiro da Silva', 'edcatiara@terra.com.br', '1955-10-24','EPTG QE 3 Proje��o A6 Ap. 301 Guar� Ville Bras�lia', '71100-106', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Marinna Gomes Almeida', 'marinnalmeida@yahoo.com.br', '1988-04-23','SHCGN 707 Bl. H casa 32', '70740-738', 'Universidade de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Kamylla Mesquita', 'kamyllaodonto@hotmail.com', '1987-06-09','', '', 'FOPLAC', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'F�dua Helou Netto', 'faduahn@yahoo.com.br', '1988-03-04','HIGS 703 bl Q casa 55', '70331-717', 'UnB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Regiane Santana Claudino', 'regianeclaudino@yahoo.com.br', '1981-01-31','SQS 305 BLOCO I PORTARIA', '70352-090', 'UNIP', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Simone Silva', 'sissi12@hotmail.com', '1977-12-25','SQN 105 Bl B ap 105', '70734-020', 'CEUB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'william da silva', 'will.whaly@gmail.com', '1988-05-01','rua mucio teixeira, 148', '90050-360', '', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Carlos Filipe Viana Matos', 'ju_filipe@yahoo.com.br', '1987-02-10','QE 42 conj.S casa 01', '71070-165', 'Universidades Paulista-UNIP', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Carlos Filipe Viana Matos', 'ju_filipe@yahoo.com.br', '1987-02-10','QE 42 conj.S casa 01', '71070-165', 'Universidades Paulista-UNIP', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Jana�na Castro de Faria', 'janainacastrodefaria@yahoo.com.br', '1987-06-10','SQN 214 bl.I apt.208 asa norte', '70873-090', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Marcos Antonio de Sousa Melo', 'msousamelo@gmail.com', '1977-03-09','QI 08 Conjunto W casa 15 Guar� I', '71010-245', 'Alto Nivel', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Janaina P. de Matos', 'ulisses@fis.unb.br', '1984-04-24','Cr-70 cs152 Vale do Amanhecer', '', 'Alub', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Rebeka de Oliveira Moura', 'rebeka_moura@yahoo.com', null,'', '', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Saulo Nacif Ara�jo', 'snacif@gmail.com', '1980-02-26','', '', 'UNIEURO', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'jhonatan r bender', 'jhonatanbender27@yahoo.com.br', '1980-08-27','edmundo baumhardt 48', '96825-570', 'unisc', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Allan Brasil dos Santos Junior', 'junior62@ibest.com.br', '1962-09-06','QE 28 conjunto M casa 51 Guar� II', '71060-132', 'Universidade de Uberaba', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'VAL�RIA FERREIRA DA SILVA', 'VAL.ADMUCB@GMAIL.COM', '1984-10-08','QN 07 C CONJUNTO 05 CASA 05 RIACHO FUNDO 2', '71880-030', 'UNIVERSIDADE CAT�LICA DE BRAS�LIA', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Leonrdo', 'leopaim@ig.com', null,'', '', 'ufba', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'shirley correa da cunha', 'shirley.cunha@br.unisys.com', null,'sqs 403 b b 106', '70237-020', 'UNIP', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Roberto de France Moreira J�nior', 'robertodefrance@pop.com.br', '1979-01-09','Rua Waldemar Guido Vicentini,292', '94015-150', 'Universidade Federal do Rio Grande do Sul', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Gabriela P�voa P. Parente', 'gabipovoa@terra.com.br', null,'SQS 313 BLOCO G APT 203', '70382-070', 'UNIVERSIDADE DE BRAS�LIA', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'J�natas Leonardo Gomes Ramalho', 'jonatasramalho@ig.com.br', '1970-02-02','SQS 103 Bloco H - 107', '70342-080', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Elizangela Moura Pereira', 'elijuiza@gmail.com', '1973-10-06','QNG 32 casa 54', '72130-320', 'Universidade Catolica de Brasilia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Roberto Souza Guedes', 'guedes.roberto@gmail.com', '1981-05-08','SQN 115 bloco G ap 505', '70772-070', 'UnB/FAU', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Robson Jacinto de Sousa', 'robsonsousa', '1984-04-02','', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Robson Jacinto de Sousa', '', '1984-04-02','', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Robson Jacinto de Sousa', 'robsonsousa@gmail.com', '1984-04-02','Casa do Estudante Universit�rio, Bloco A, ap. 204, Asa Norte, Bras�la', '70910-900', 'Universidade de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Breno Paradelo Garcia', 'brenobsb@gmail.com', null,'', '', 'UCB', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Rodrigo Santino', 'rodrigosantino@gmail.com', '1982-11-23','Rua S�o Francisco Xavier, 152 apt. 301', '20500-012', 'ESPM', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Isabella Mendon�a Guerreiro', 'isabellamg@ig.com.br', '1983-08-12','Rua Hugo Alvarenga Porto, 115', '24738-675', 'UFRJ', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Eliana de Oliveira', 'elianabinat@yahoo.com.br', '1973-02-28','alameda das ac�cias qd.107 bloco a apt.403 -�guas claras', '70030-100', 'FEPAD - Funda��o de Estudos e Pesquisas em Administra��o e Desenvolvimento', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Arley Marciel Rodrigues da Cunha', 'arleymarciel@gmail.com', '1979-05-14','Qr 414 Conjunto 16 Casa 31', '72320-222', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'JUCIMAR BARBOSA BRAGA', 'JUCIMAR@BLOJAF.COM.BR', '1978-06-04','R. FATIMA, 111 APTO 208 BLOCO 03', '33940-050', 'PONTIFICIA UNOVERSIDADE CATOLICA', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'JONATHAN OLIVEIRA PACHECO', 'jony_pach@yahoo.com.br', null,'SMPW Q. 20 CONJ. 01 LT 5 D', '71745-001', 'UnB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Jones Madruga', 'jonesmadruga@gmail.com', '1986-01-07','SQS 115 bloco G apto 302', '70385-070', 'UnB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Paulo Roberto Nery Ribeiro', 'prnr@pop.com.br', '1971-02-25','SQN 313 Bl. B apt 607', '70766-020', 'Unidf', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'fernando hunhoff', 'hunhoff81@yahoo.com.br', null,'', '', 'UNISC', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'aline albernaz santana', 'aline_proade@yahoo.com.br', null,'qse 03 casa 61 taguatinga sul - df', '72025-030', 'universidade catolica de brasilia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Ricardo Klinger Izidoro Lima', 'ricardo.lima01@hotmail.com', '1988-06-26','', '', 'Universidade Cat�lica de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'JOS� ROG�RIO DE JESUS ABRANTES', 'ROGERIOABRANTES3@POP.COM.BR', null,'QNM 36 CONJUNTO O CASA 29', '72615-145', 'FACULDADE PROJE��O', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Brigida de Araujo Noa', 'brigidanoa@gmail.cm', '1982-03-12','', '', '', '' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Izabela Cristina Marques de Oliveira', 'izabela.marques@gmail.com', '1981-01-14','Quadra 35 Casa 05 Etapa B Valparaiso I', '72876-130', 'FIPLAC - Faculdades Integradas do Planalto Central', 'GO' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Osmar Eduardo Nothaft', 'osmaren@yahoo.com.br', null,'', '', 'UNISC', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'kleber reis', 'vo2sport@pop.com.br', '1976-06-11','cas ch 106 a lote 6a', '72110-600', 'universidade cat�lica de bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Camila de Medeiros Escobar', 'camila_escobar@hotmail.com', '1987-06-18','', '71665-225', 'UnB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Ana Beatriz Alves Franco', 'anabiafranco@gmail.com', '1986-06-13','SQN 208, Bloco H, Apto 104', '70853-080', 'UnB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'RENATO NEVES', 'renato.neves@souzacruz.com.br', '1979-07-20','', '', 'UPIS', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Paula Ramalho N�brega Sant�Ana', 'paularns@bol.com.br', null,'SQN 215 bl F apt. 303', '70874-060', 'UNB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Maria Silvana Lima Domingos', 'silvana_lima@superig.com.br', null,'', '', 'IESB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Rodrigo Vecchi Martins da Cunha', 'rodrigovmc@gmail.com', '1982-01-28','SQN 111 Bloco A Ap. 601', '70754-010', 'UnB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Pedro Henrique Benite', 'pbenite@gmail.com', '1983-11-30','SHIS QI 27 Conjunto 17 Casa 15', '71675-170', 'UniCEUB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Amanda Botelho Soares Oliveira', 'amandinhabotelho@yahoo.com.br', null,'sqs 207 bl d ap 204', '70253-040', 'Universidade de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Amanda Botelho Soares Oliveira', 'amandinhabotelho@yahoo.com.br', null,'sqs 207 bl d ap 204', '70253-040', 'Universidade de Bras�lia', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'HAYLA SILVA', 'hayla_silva@hotmail.com', null,'', '', '', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Fernanda Malagutti', 'fefemrc@zipmail.com.br', '1986-01-01','rua da abobrinha', '', 'UNESP', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'J�lia Menezes David', 'juliadavid3@gmail.com', null,'', '', 'UNB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Luiz henrique dos Santos', 'henriquedelza@gmail.com', '1966-10-07','Rua Santa Terezinha, 180-apt203 Ponto Novo- Aracaju', '49047-460', 'Faculdade de Sergipe', 'SE' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Giancarlo Fernandes Silva', 'giancarlofs@gmail.com', '1985-04-18','QNN-20 Conj-H casa-04', '72220-208', 'Universidade de Brasilia-UnB', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'ADRIANA DE ASSIS S. SIQUEIRA', 'dricaassis@gmail.com', null,'SHCGN 711 BL G APT 106', '70750-767', 'UNIP-DF', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Eloisa de Sousa Cantu�ria', 'cantuaria@ucb.br', '1967-09-03','HIGS 703 BL C CASA 23', '70331-703', 'Universidade Cat�lica', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Paulina Santos da Silva', 'paulina.silva@souzacruz.com.br', null,'Rua rio rande 770', '94828-620', '', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'cicero monteiro', 'gastromonteiro@bol.com.br', '1973-03-23','rua fonseca teles 99', '', 'univercidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Roberto Simas', 'roberto.simas@gmail.com', null,'', '', '', 'SP' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Jonas Abreu da Silva', 'jonas_abreu@walla.com', '1987-01-03','Rua Cassipor�, S/N� LT32 QD65', '25036-040', '', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Rafael Gon�alves Lima', 'rafaelgoncalveslima@yahoo.com.br', '1986-04-22','R.potiguara 217, ap 801 - JPA', '22750-290', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Augusto Falco', 'augustofalco@yahoo.com.br', '1986-05-11','Rua Adomervil Moreira Miranda N� 856', '38414-300', 'Universidade Federal de Uberl�ndia', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'arlinda ferreira leite', 'arlindaferreiraleite@yahoo.com.br', null,'rua jose de alencar 447/403', '50070-030', 'UFPE', 'PE' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Ana Paula de Ara�jo', 'paulaaedes@hotmail.com', '1981-10-15','Av. S�o Paulo', '50781-600', 'UFPE', 'PE' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'MIchele Aparecida Xavier Falco', 'michele_psicologia@yahoo.com.br', '1983-03-24','Rua Adomervil Moreira Miranda n� 856, bairro Luizote de Freitas, cidade Uberl�ndia', '38414-300', 'Universidade Federal de Uberl�ndia (UFU)', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'fabiano mota machado', 'fabianomotamota@ig.com.br', '1976-04-02','qnm 36 conj x casa 19 m norte taguatinga df', '72145-624', 'unopar', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Rochana Rassier da Silva', 'rochanarassier@yahoo.com.br', null,'Rua Guilherme Hackbart, 47 Apto 104', '96820-460', 'Universidade de Santa Cruz do Sul - UNISC', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Rochana Rassier da Silva', 'rochanarassier@yahoo.com.br', null,'Rua Guilherme Hackbart, 47 Apto 104', '96820-460', 'Universidade de Santa Cruz do Sul - UNISC', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'MARIA CECILIA DOS SANTOS ANDRADE', 'zazab789@terra.com.br', '1985-10-08','SCLRN 716 BLOCO D ENTRADA 62 APT 205', '70770-534', 'UNIVERSIDADE PAULISTA', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Aline', 'alinetsg@hotmail.com', null,'Av Imbaubas 1400', '38413-108', 'UFU', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'murilo alves silva de oliveira', 'muia_alves@hotmail.com', '1987-02-26','rua rogerio de faria', '41940-300', 'universidade ferderal da bahia', 'BA' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Marden Del  Isola de Sousa Marques', 'marques@uber.com.br', '1981-04-07','Rua Cyro Avelino Franco 405', '38411-174', 'UFU - Universidade Federal de Uberl�ndia', 'MG' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Joseane Frantz', 'joseane@idbinfo.com.br', null,'Rua Para 151', '96845-490', 'UNISC', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'TATIANA DOS SANTOS ROCHA', 'tatianadrocha@ig.com.br', '1984-05-17','QNP 10 CONJ Q CASA 46', '72230-100', 'UNIVERSIDADE CATOLICA DE BRASILIA', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Vando Vieira Batista dos Santos', 'vandodmj@yahoo.com.br', '1987-04-10','Rua 43 Quadra 04 casa 01', '72880-000', 'Faculdade Michelangelo', 'GO' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Carolinne Bento Duarte', 'carolinne_duarte@yahoo.com.br', null,'Pra�a Santos Dumont 138/506 Bloco B G�vea', '22470-060', 'PUC - Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Douglas Muniz', 'douglaskz@yahoo.com.br', null,'Rua sobradinho, 965', '96840-500', 'UNISC', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Carine Svarovsky', 'carines@mx2.unisc.br', '1976-06-25','Rua Senhor dos Passos, 232 apto 403', '96640-000', 'UNISC', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'william da silva', 'will.whaly@gmail.com', '1988-05-01','rua m�cio teixeira 148', '90050-360', 'Unificado pr�-vestibular', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'ANA CAROLIN PONTES FRAN�A', 'anacarolina_pontes@hotmail.com', '1981-03-10','Rua S�o Zacarias, n� 129, bairro Maur�cio de Nassau, Caruaru', '55012-240', 'FACULDADE DO VALE DO IPOJUCA - FAVIP', 'PE' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Gabriela de Oliveira Teixeira', 'bienicole@ig.com.br', null,'Rua Conde D Eu, 171 / 205 - Barra da Tijjuca', '22611-050', 'PUC-Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'LUANA DOS SANTOS FLORES', 'luana666@cesuca.com.br', '1985-08-07','FILIPINAS,325 GRAVATA�', '94090-020', 'FACULDADE INEDI-CESUCA', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'julio cesar dantas de lacerda', 'juliolac8@hotmail.com', '1979-06-25','ccsw 01 lt 4 bloco c 417', '70680-150', 'uniceub', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'luciana de freitas rodrigues', 'lucianafrodrigues@hotmail.com', '1979-12-17','ccsw 01 lt 4 bl c 417', '70680-150', 'uniceub', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'ALEXANDRE ANDR� MOREIRA DOS SANTOS', 'alexandreandremds@gmail.com', null,'SQSW 303 BLOCO I APARTAMENTO 401', '70673-309', 'UNIVERSIDADE CAT�LICA DE BRAS�LIA', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'ALEXANDRE ANDR� MOREIRA DOS SANTOS', 'alexandreandremds@gmail.com', '1985-07-08','SQSW 303 BLOCO I APARTAMENTO 401', '70673-309', 'UNIVERSIDADE CAT�LICA DE BRAS�LIA', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Vagner Kohn Behling', 'vagneragro@yahoo.com.br', null,'Av. 25 de Julho, 370', '96065-620', 'Universidade Federal de Pelotas', 'RS' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Ryan Souza Guedes', 'baianosg@pop.com.br', null,'qi 12, bl o, apt. 105 guar�', '71010-159', 'Faculdade Michelangelo', 'DF' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Allyne Raffler', 'aallyne@gmail.com', '1986-05-13','rua Professor Assis Gon�alves, 650 apto 705', '80620-250', 'Universidade Federal do Paran�', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'daniel Marcelino da Silva', 'dmsilv@gmail.com', '1977-07-12','Rua Luiz Le�o, 01 ap. 423', '80030-010', 'Universidade Federal do Paran�', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bolinho', 'g.iyama@hotmail.com', '1985-02-16','Rua S�o Francisco Xavier, 152', '20520-050', 'Universidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bolinho', 'g.iyama@hotmail.com', '1985-02-16','Rua S�o Francisco Xavier, 152', '20520-050', 'Universidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bolinho', 'g.iyama@hotmail.com', '1985-02-16','Rua S�o Francisco Xavier, 152', '20520-050', 'Universidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bolinho', 'g.iyama@hotmail.com', '1985-02-16','Rua S�o Francisco Xavier, 152', '20520-050', 'Universidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bolinho', 'g.iyama@hotmail.com', '1985-02-16','Rua S�o Francisco Xavier, 152', '20520-050', 'Universidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bolinho', 'g.iyama@hotmail.com', '1985-02-16','Rua S�o Francisco Xavier, 152', '20520-050', 'Universidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bolinho', 'g.iyama@hotmail.com', '1985-02-16','Rua S�o Francisco Xavier, 152', '20520-050', 'Universidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Elaine Melo Renesto', 'lainerenesto@ig.com.br', '1985-12-08','rua jardim olinda, 08', '81935-320', 'Centro Universitario Campos de Andrade', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Andrea C�rtes', 'deiacortes@yahoo.com.br', '1984-06-04','Milton Camargo de Oliveira, 96', '82315-050', 'UFPR', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bolinho', 'gregory@console.com.br', '1985-02-16','Rua S�o Francisco Xavier, 152', '20520-050', 'Universidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'patricia atanasio', 'pati_ufpr@hotmail.com', '1978-06-21','rua des.joao antonio de barros jr 915', '81810-300', 'ufpr', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bolinho', 'gregory.iyama@console.com.br', '1985-02-16','Rua S�o Francisco Xavier, 152', '20520-050', 'Universidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bolinho', 'gregory@console.com.br', '1985-02-16','Rua S�o Francisco Xavier, 152', '20520-050', 'Universidade', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bolinho', 'g.iyama@console.com.br', '1985-02-16','Rua', '2', 'u', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Bolinho', 'g.iyama@hotmail.com', '2525-02-16','�ih', 'ophi', 'o�gh', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Pero Hespanha', 'phhesp@hotmail.com', null,'Av. Sete de setembro', '83206-270', 'PUCPR/Rural Max', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Julyane Cristina Candido', 'julyane@sulbbs.com.br', '1985-03-16','Pra�a Santos Andrade, 39, ap. 123', '80020-300', 'Universidade Federal do Paran�', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Rafael Sartori Ranucci', 'rafael_ranucci@yahoo.com.br', '1981-03-17','Av. Igua�u, 2121', '80240-030', 'UTFPR', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'rodrigo fernandes queiroz teixeira', 'rodrigo.queiroz@gmail.com', '1977-07-27','av guilherme pugsley 2650', '80610-300', 'universidade federal do parana', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'fernanda duarte', 'fernandaduarte@argentina.com', '1984-12-13','avenida presidente afonso camargo, 2305, ap 902', '80050-370', 'PUC Paran�', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Adriana Ramos de Sene', 'sene_adriana@yahoo.com.br', '1982-05-02','R Arcione Cantador Grabowski, 263', '83704-720', 'Universidade Tecnol�gica Federal do Paran�', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Paula Matoski Butture', 'lorettes@gmail.com', '1984-10-18','R. Conselheiro Carr�o 217 ap.32', '80040-130', 'PUC-PR', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'gabriela thiesen da silveira', 'gabi_thiesen@hotmail.com', '1986-03-11','curt roters 79', '81750-120', 'puc pr', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'ELIANE DANIELE KAVALKIEVICZ', 'elianedkavalkievicz@yahoo.com.br', '1980-01-09','Nossa Sra. Cabe�a, 1940', '81310-010', 'PUC PR', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Erikson Ribeiro dos Santos', 'eriksonsantos@curitiba.org.br', '1984-07-21','Av. Senador Souza Naves n�635 apto 91', '80050-040', 'Pontificia Universidade Catolica', 'PR' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'Nathalia Cuitino Manso', 'natizinha_cm@hotmail.com', null,'Rua General Garzon 100/103', '22470-010', 'PUC- Rio', 'RJ' );
INSERT INTO newsletter_mail(cd_site_newsletter_mail,nome_newsletter_mail, email_newsletter_mail, nascimento_newsletter_mail,endereco_newsletter_mail,  cep_newsletter_mail, instituicao_newsletter_mail, estado_newsletter_mail) VALUES
	 (53,'', '', null,'', '', '', '' );
