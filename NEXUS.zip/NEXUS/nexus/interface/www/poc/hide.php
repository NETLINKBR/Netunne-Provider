<html>

<body>

<table width="100%" border="1" name="">
	<tr>
		<td>
			coluna 1
		</td>
		<td>
			Coluna 2
		</td>
	</tr>
	
	<div id="group1" style="position:absolute">
	<tr>
		<td>
			Valor 1
		</td>
		<td>
			Valor 2
		</td>
	</tr>
	</div>
	
</table>

<input type="button" onclick="esconder('group1')" value="Esconder">


</body>
</html>