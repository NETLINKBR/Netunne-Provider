<?php
	/****************************************************************
	*																*
	* 			Console Tecnologia da Informa��o Ltda				*
	* 				E-mail: contato@console.com.br					*
	* 				Arquivo Criado em 17/10/2006					*
	*																*
	****************************************************************/

	include "../common.php";
	
	
	header('Content-Type: text/html; charset=ISO-8859-1');

	echo conv::formatdate(time());


?>
