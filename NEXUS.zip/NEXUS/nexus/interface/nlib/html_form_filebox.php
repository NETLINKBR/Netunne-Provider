<?php
	/****************************************************************
	*																*
	* 			Console Tecnologia da Informa��o Ltda				*
	* 				E-mail: contato@console.com.br					*
	* 				Arquivo Criado em 29/05/2006					*
	*																*
	****************************************************************/


?>
<script language="JavaScript">
	form_<?=$formname?>_fields[<?=$itemcount?>]='<?=$name?>';
	form_<?=$formname?>_types[<?=$itemcount?>]='filebox';
</script>
<table cellspacing=0 cellpadding=0 border=0><tr>
	<td>
<input type="file" class="filebox" size="23"
	name="<?=$name?>" id="filebox_<?=$name?>" 
	style="width:241px"
	>
	</td>
	<td><!-- mascara -->
	</td>
</tr></table>