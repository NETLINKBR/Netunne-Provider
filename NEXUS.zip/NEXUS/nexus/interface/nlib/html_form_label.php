<?php
	/****************************************************************
	*																*
	* 			Console Tecnologia da Informa��o Ltda				*
	* 				E-mail: contato@console.com.br					*
	* 				Arquivo Criado em 21/07/2006					*
	*																*
	****************************************************************/


?>
<input type="hidden" name="<?=$name?>" value="<?=$value?>">
<span class="tablecell_form_label"><?=$value?></span>
