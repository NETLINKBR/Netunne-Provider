<?php
	/****************************************************************
	*																*
	* 			Console Tecnologia da Informa��o Ltda				*
	* 				E-mail: contato@console.com.br					*
	* 				Arquivo Criado em 21/07/2006					*
	*																*
	****************************************************************/


?>
<HTML>
  <BODY><SCRIPT><? if ($parent==1) { ?>parent.<? }?>location.href='<?=$url?>';</SCRIPT></BODY>
</HTML>
