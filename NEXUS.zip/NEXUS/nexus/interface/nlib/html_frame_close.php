<?php
	/****************************************************************
	*																*
	* 			Console Tecnologia da Informa��o Ltda				*
	* 				E-mail: contato@console.com.br					*
	* 				Arquivo Criado em 27/05/2006					*
	*																*
	****************************************************************/


?>
<!-- FRAME CLOSE -->
</td>
			<td width="8" bgcolor="#1E3560"></td>
		</tr>
		<tr>
			<td width="8" valign=bottom bgcolor="#1E3560"><img src="<?=DIRIMG?>frame_bottomleft.gif"></td>
			<td width="548" bgcolor="#1E3560"></td>
			<td width="8" bgcolor="#1E3560" valign=bottom><img src="<?=DIRIMG?>frame_bottomright.gif"></td>
		</tr>
	</table>
</div>
<div style="height:20px"></div>
<!-- / FRAME CLOSE -->