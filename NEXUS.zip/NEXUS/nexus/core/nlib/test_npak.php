<?php
	/****************************************************************
	*																*
	* 			Console Tecnologia da Informa��o Ltda				*
	* 				E-mail: contato@console.com.br					*
	* 				Arquivo Criado em Sep 2, 2006					*
	*																*
	****************************************************************/

	include "common.nx";
	
	$n =new Npak();
	$n->autoinstall();
	

?>
