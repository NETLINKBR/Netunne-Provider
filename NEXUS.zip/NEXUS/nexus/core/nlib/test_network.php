<?php
	/****************************************************************
	*																*
	* 			Console Tecnologia da Informa��o Ltda				*
	* 				E-mail: contato@console.com.br					*
	* 				Arquivo Criado em 30/03/2006					*
	*																*
	****************************************************************/

include_once "common.nx";

$a=new Network();
$a->merge();

//echo "Primary: ".Network::getprimary();

/*
$i = new Net_ipv4();


$i->parseAddress("10.0.0.1/16");

$faixa1 = ip2long("10.0.0.10");
$faixa2 = $faixa1+1000;
echo long2ip($faixa2);
*/
?>
