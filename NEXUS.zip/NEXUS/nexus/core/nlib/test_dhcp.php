<?php

include_once "common.nx";

$dhcp = new Dhcp();
print_r($dhcp->merge());

?>
